import Account from "../Account"
import Frame from "../Frame"
import * as ResultBuilder from "./ResultBuider"


export default class Result {
    constructor(
        public readonly frames: Frame[],
        public readonly accounts: Account[]
    ) {
        ResultBuilder.build(frames, accounts)
    }
}